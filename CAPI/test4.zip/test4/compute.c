#include "math.h"

#include "WolframRTL.h"

static WolframCompileLibrary_Functions funStructCompile;

static LibraryFunctionPointer FP0;

static MArgument FPA[4];


static mint I0_0;

static mbool initialize = 1;

#include "compute.h"

DLLEXPORT int Initialize_compute(WolframLibraryData libData)
{
if( initialize)
{
funStructCompile = libData->compileLibraryFunctions;
I0_0 = (mint) 4;
FP0 = funStructCompile->getFunctionCallPointer("Dot");
if( FP0 == 0)
{
return LIBRARY_FUNCTION_ERROR;
}
initialize = 0;
}
return 0;
}

DLLEXPORT void Uninitialize_compute(WolframLibraryData libData)
{
if( !initialize)
{
initialize = 1;
}
}

DLLEXPORT int compute(WolframLibraryData libData, MTensor A1, MTensor *Res)
{
MTensor* T0_0;
MTensor* T0_1;
MTensorInitializationData Tinit;
MArgument FPA[4];
int err = 0;
Tinit = funStructCompile->GetInitializedMTensors(libData, 1);
T0_1 = MTensorInitializationData_getTensor(Tinit, 0);
T0_0 = &A1;
MArgument_getMTensorAddress(FPA[0]) = T0_0;
MArgument_getMTensorAddress(FPA[1]) = T0_0;
MArgument_getIntegerAddress(FPA[2]) = &I0_0;
MArgument_getMTensorAddress(FPA[3]) = T0_1;
err = FP0(libData, 3, FPA, FPA[3]);/*  Dot  */
if( err)
{
goto error_label;
}
funStructCompile->MTensor_copy(Res, *T0_1);
error_label:
funStructCompile->ReleaseInitializedMTensors(Tinit);
funStructCompile->WolframLibraryData_cleanUp(libData, 1);
return err;
}

