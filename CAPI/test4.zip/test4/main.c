#include <stdio.h>

#include "compute.h"

#include "WolframRTL.h"

static WolframLibraryData libData = 0;

int main(int argc, char *arg[])
{
//  printf("................");

int err = 0;

int i,j,n=3;
double *data,*result;
MTensor x,y;

libData = WolframLibraryData_new(WolframLibraryVersion);

mint type,rank,*dims;
type = MType_Real;

double num2;

  type = MType_Real;
  rank = 2;
  dims = (mint*)malloc(rank * sizeof(mint));
  dims[0] = n;
  dims[1] = n;
  mint position[2];

  err = (*(libData->MTensor_new))(type, rank, dims, &x);
  if (err) return 1;
  err = (*(libData->MTensor_new))(type, rank, dims, &y);
  if (err) return 1;
  free(dims);


data = libData->MTensor_getRealData( x );
for(i=0;i<n;i++)
	for(j=0;j<n;j++){
	  data[ i*n + j ] = (double) 10*(i+1)+j+1 ;
	}


WolframLibraryData libData = WolframLibraryData_new(WolframLibraryVersion);
Initialize_compute(libData);

compute(libData, x , &y);



result = libData->MTensor_getRealData( y );
for(i=0;i<n;i++){
	for(j=0;j<n;j++)printf("\t%f",result[i*n+j]);
	printf("\n");
	}


libData->MTensor_free(x);
libData->MTensor_free(y);		

WolframLibraryData_free(libData);

Uninitialize_compute(libData);
return 0;
}

