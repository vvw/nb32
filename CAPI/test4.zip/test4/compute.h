#include "WolframLibrary.h"

EXTERN_C DLLEXPORT int Initialize_compute(WolframLibraryData libData);

EXTERN_C DLLEXPORT void Uninitialize_compute(WolframLibraryData libData);

EXTERN_C DLLEXPORT int compute(WolframLibraryData libData, MTensor A1, MTensor *Res);

